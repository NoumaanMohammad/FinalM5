package com.cg.ars.dao;

import java.util.List;

import com.cg.ars.dto.BookingInformation;
import com.cg.ars.exception.AirLineManagementException;

public interface BookingInformationDao {
	

	public BookingInformation getBookingDetailsById(int bookId) throws AirLineManagementException;
	public int deleteBookingById(int bookId) throws AirLineManagementException;
	public int bookTicket(BookingInformation booking) throws AirLineManagementException;
	public int sequenceForSeats() throws AirLineManagementException;
	public BookingInformation updateTicketDetails(BookingInformation oldBooking,BookingInformation newBooking) throws AirLineManagementException;
	
	//anagha
	public List<BookingInformation> getpassengerInformationOnAirLines(
			int flForPassenger);
}
