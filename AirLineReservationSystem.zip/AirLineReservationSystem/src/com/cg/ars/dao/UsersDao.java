package com.cg.ars.dao;

import com.cg.ars.dto.Users;
import com.cg.ars.exception.AirLineManagementException;

public interface UsersDao {
	public Users validateAdminCredentials(Users admin) throws AirLineManagementException;

}
