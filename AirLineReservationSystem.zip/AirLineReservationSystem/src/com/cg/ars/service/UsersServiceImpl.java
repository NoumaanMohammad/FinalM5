package com.cg.ars.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ars.dao.UsersDao;
import com.cg.ars.dto.Users;
import com.cg.ars.exception.AirLineManagementException;

@Service
@Transactional
public class UsersServiceImpl implements UsersService {
	
	@Autowired
	UsersDao dao;
	
	@Override
	public Users validateAdminCredentials(Users admin)
			throws AirLineManagementException {

		return dao.validateAdminCredentials(admin);
	}

}
