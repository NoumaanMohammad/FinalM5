package com.cg.ars.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.print.attribute.standard.DateTimeAtCompleted;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ars.dao.FlightInformationDao;
import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;
import com.sun.xml.internal.ws.api.ha.StickyFeature;
@Service
@Transactional
public class FlightInformationServiceImpl implements FlightInformationService 
{
	@Autowired
	FlightInformationDao fdao;
	//(rollbackFor=AirLineManagementException.class)
	@Override
	public void addFlight(FlightInformation flightInfo) 	throws AirLineManagementException {
		if(isValid(flightInfo))
		{
			fdao.addFlight(flightInfo);
		}else
		{
			throw new AirLineManagementException("Invalid date,Arrival Date and time should be less than departure data and time");
		}
	}
	
	private boolean isValid(FlightInformation flightInfo)
	{	
		Date dDate = flightInfo.getDeptDate();
		Date aDate = flightInfo.getArrDate();
		String dTime = flightInfo.getDeptTime();
		String aTime = flightInfo.getArrTime();
		dDate.setHours(Integer.parseInt(dTime.substring(0,dTime.indexOf(":"))));
		dDate.setMinutes(Integer.parseInt(dTime.substring(dTime.indexOf(":")+1)));
		aDate.setHours(Integer.parseInt(aTime.substring(0,aTime.indexOf(":"))));
		aDate.setMinutes(Integer.parseInt(aTime.substring(aTime.indexOf(":")+1)));
		/*System.out.println("dDate : "+dDate+" aDate : "+aDate);
		System.out.println("res : "+dDate.compareTo(aDate));*/
		Date todaysDate = new Date();
		if(dDate.compareTo(aDate)<0 && (todaysDate).compareTo(dDate)<0)
			return true;
		else 
			return false;
	}

	@Override
	public FlightInformation getFlightById(int FlightNum)
			throws AirLineManagementException {
		
		
		return fdao.getFlightById(FlightNum);
		
		
	}

	@Override
	public FlightInformation updateFlightFaresById(FlightInformation fares)
			throws AirLineManagementException {
		return fdao.updateFlightFaresById(fares);
	}

	@Override
	public FlightInformation updateFlightCitiesById(FlightInformation cities)
			throws AirLineManagementException {
		return fdao.updateFlightCitiesById(cities);
		
	}

	@Override
	public FlightInformation updateFlightScheduleById(FlightInformation flight)
			throws AirLineManagementException {
		
		FlightInformation flightInfo;
		if(isValid(flight))
		{
			flightInfo=fdao.updateFlightScheduleById(flight);
		}else
		{
			throw new AirLineManagementException("Invalid date,Arrival Date and time should be less than departure data and time");
		}
		return flightInfo;
	}

	@Override
	public List<FlightInformation> getFlightDetailsByCities(String srcCity,
			String destCity) throws AirLineManagementException {
		return fdao.getFlightDetailsByCities(srcCity, destCity);
	}

	@Override
	public List<FlightInformation> getflightInformationOnDestination(String destination)
			throws AirLineManagementException {
		return fdao.getflightInformationOnDestination(destination);
	}

	@Override
	public List<FlightInformation> getflightInformationOnDay(Date day) throws AirLineManagementException {
		return fdao.getflightInformationOnDay(day);
	}

	@Override
	public List<FlightInformation> getflighInformationOnAirLines(String airline) throws AirLineManagementException {
		return fdao.getflighInformationOnAirLines(airline);
	}

	@Override
	public List<FlightInformation> getflighDetailsByDate(Date dep, Date des) throws AirLineManagementException {
		return fdao.getflighDetailsByDate(dep, des);
	}
	
	/*public static void main(String[] args) {
		
		FlightInformation fl = new FlightInformation();
		
		Date dDate = null;
		Date aDate = null;
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		try {
			dDate = format.parse("18-08-2018");
			aDate = format.parse("18-08-2018");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		fl.setDeptdate(dDate);
		fl.setArrdate(aDate);
		
		fl.setDepttime("08:45");
		fl.setArrtime("08:45");
		
		System.out.println(new FlightInformationServiceImpl().isValid(fl));
	}*/
}


