package com.cg.ars.service;

import com.cg.ars.dto.Users;
import com.cg.ars.exception.AirLineManagementException;

public interface UsersService {
	public Users validateAdminCredentials(Users admin) throws AirLineManagementException;


}
