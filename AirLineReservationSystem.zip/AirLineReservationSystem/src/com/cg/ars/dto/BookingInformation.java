package com.cg.ars.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="bookinginformation")
public class BookingInformation {
	
	@Override
	public String toString() {
		return "BookingInformation [bookingId=" + bookingId + ", email="
				+ email + ", passengers=" + passengers + ", classType="
				+ classType + ", totalFare=" + totalFare + ", seatNumber="
				+ seatNumber + ", creditCardInfo=" + creditCardInfo
				+ ", sourceCity=" + sourceCity + ", destCity=" + destCity
				+ ", flightno=" + flightno + "]";
	}
	@Id
	@Column(name="booking_id")
	@SequenceGenerator(name="book_id_seq",sequenceName="",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="book_id_seq")
	private int bookingId;
	
	@Column(name="cust_email")
	@Pattern(regexp="^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$",message="Invalid Email")
	private String email;
	
	@Column(name="no_of_passengers")
	@Min(value=1)
	private int passengers;
	
	@Column(name="class_type")
	private String classType;
	
	@Column(name="total_fare")
	private double totalFare;
	
	@Column(name="seat_number")
	private String seatNumber;
	
	@Column(name="creditcard_info")
	@NotEmpty
	@Pattern(regexp="[0-9]{16},[a-zA-Z]{2,20},[0-9]{3},[0-9]{2}/[0-9]{2}",message="Enter valid card details")
	private String creditCardInfo;
	
	@Column(name="src_city")
	private String sourceCity;
	
	@Column(name="dest_city")
	private String destCity;
	
	@Column(name="flightno")
	private int flightno;
	
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPassengers() {
		return passengers;
	}
	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
	public double getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}
	public String getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
	public String getCreditCardInfo() {
		return creditCardInfo;
	}
	public void setCreditCardInfo(String creditCardInfo) {
		this.creditCardInfo = creditCardInfo;
	}
	public String getSourceCity() {
		return sourceCity;
	}
	public void setSourceCity(String sourceCity) {
		this.sourceCity = sourceCity;
	}
	public String getDestCity() {
		return destCity;
	}
	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}
	public int getFlightno() {
		return flightno;
	}
	public void setFlightno(int flightno) {
		this.flightno = flightno;
	}
	

}
