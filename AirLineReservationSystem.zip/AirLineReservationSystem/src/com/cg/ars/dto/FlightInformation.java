package com.cg.ars.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="flightinformation")
public class FlightInformation {
	
	@Override
	public String toString() {
		return "flightNo=" + flightNo + "\n airLine="
				+ airLine + "\n arrCity=" + arrCity + "\n deptCity=" + deptCity
				+ "\n deptDate=" + deptDate + "\n arrDate=" + arrDate
				+ "\n deptTime=" + deptTime + "\n arrTime=" + arrTime
				+ "\n firstSeats=" + firstSeats + "\n bussSeats=" + bussSeats
				+ "\n firstSeatsFare=" + firstSeatsFare + "\n bussSeatsFare="
				+ bussSeatsFare;
	}

	@Id
	@Column(name="flightno")
	private int flightNo;
	
	@NotEmpty(message="Airline should not be empty")
	private String airLine;
	
	@NotEmpty(message="arrival city should not be empty")
	@Pattern(regexp="[A-Z][a-z]{1,19}",message="First letter should be capital and maximum lentgh is 20 characters")
	@Column(name="arr_city")
	private String arrCity;
	
	@NotEmpty(message="departure city should not be empty")
	@Pattern(regexp="[A-Z][a-z]{1,19}",message="First letter should be capital and maximum lentgh is 20 characters")
	@Column(name="dep_city")
	private String deptCity;
	
	
	
	@Column(name="dep_date")
	private Date deptDate;
	
	@Column(name="arr_date")
	private Date arrDate;
	
	@NotEmpty(message="Time should not be empty")
	@Column(name="dep_time")
	private String deptTime;
	
	@NotEmpty(message="Time should not be empty")
	@Column(name="arr_time")
	private String arrTime;
	
	@Column(name="FirstSeats")
	private int firstSeats;
	
	@Column(name="BussSeats")
	private int bussSeats;
	
	@Column(name="FirstSeatFare")
	@Min(value=1,message="fare should not be negative")
	private double firstSeatsFare;
	
	@Column(name="BussSeatsFare")
	@Min(value=1,message="fare should not be negative")
	private double bussSeatsFare;

	public int getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(int flightNo) {
		this.flightNo = flightNo;
	}

	public String getAirLine() {
		return airLine;
	}

	public void setAirLine(String airLine) {
		this.airLine = airLine;
	}

	public String getArrCity() {
		return arrCity;
	}

	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}

	public String getDeptCity() {
		return deptCity;
	}

	public void setDeptCity(String deptCity) {
		this.deptCity = deptCity;
	}

	public Date getDeptDate() {
		return deptDate;
	}

	public void setDeptDate(Date deptDate) {
		this.deptDate = deptDate;
	}

	public Date getArrDate() {
		return arrDate;
	}

	public void setArrDate(Date arrDate) {
		this.arrDate = arrDate;
	}

	public String getDeptTime() {
		return deptTime;
	}

	public void setDeptTime(String deptTime) {
		this.deptTime = deptTime;
	}

	public String getArrTime() {
		return arrTime;
	}

	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}

	public int getFirstSeats() {
		return firstSeats;
	}

	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}

	public int getBussSeats() {
		return bussSeats;
	}

	public void setBussSeats(int bussSeats) {
		this.bussSeats = bussSeats;
	}

	public double getFirstSeatsFare() {
		return firstSeatsFare;
	}

	public void setFirstSeatsFare(double firstSeatsFare) {
		this.firstSeatsFare = firstSeatsFare;
	}

	public double getBussSeatsFare() {
		return bussSeatsFare;
	}

	public void setBussSeatsFare(double bussSeatsFare) {
		this.bussSeatsFare = bussSeatsFare;
	}
	
	
	
	
}

	

